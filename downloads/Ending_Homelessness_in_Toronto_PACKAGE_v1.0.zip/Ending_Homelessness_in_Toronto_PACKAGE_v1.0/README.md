# Ending Homelessness in Toronto — the flagship package

A roadmap to stop the inflow, build the best emergency shelter system in the world, and house
everyone who is homeless today — for less than the crisis costs us now.

## What's in this package

- **`Ending_Homelessness_in_Toronto_FLAGSHIP_v1.0.pdf`** — the executive summary (the flagship
  question, the case in one paragraph, and the full summary, every claim carrying its receipt)
  followed by all 28 research backgrounders, bound as one print-ready document.
- **`site/`** — the same 28 backgrounder pages as a self-contained offline website. Open any
  `site/homelessness-*.html` file in a browser; every in-page link and receipt works with no
  internet connection.

One readability note: the backgrounder pages here (and in the PDF) carry a plain-language
translation of the research library's internal production notation — trust-class tags,
verification codes, and process notes are rendered as ordinary words. Claims, figures,
verification statuses, and citations are unchanged, and the live pages at unitetolove.ca
remain the canonical, most-current versions.

## What's deliberately not in this package

This project also has a further-along, fully assembled book manuscript that walks the same
material as a single narrative. That manuscript is awaiting its author's own read and has not
been approved for release — it is not included here. This package is the sealed executive
framing plus the already-public backgrounder library only.

## Honest about status

Several of the 28 backgrounders carry their own DRAFT badge, and every one carries a standing
disclosure that some claims are still being checked against their original sources. Both are
kept in this edition rather than smoothed over — nothing is presented as more finished than
the live site presents it.

## Currency

This is a live research library; individual backgrounders are revised on their own schedule.
The current version of every page, and any corrections logged after this package was built, are
always at:

- https://unitetolove.ca
- https://unitetolove.ca/corrections.html

## Free to use

No attribution required. Quote it, cite it, build on it.

## Contact

unknownsoldier@unitetolove.ca — corrections, improvements, ideas, resources, and offers of
help all welcome.

---
*Packaged 2026-08-06. Built by a re-runnable script:
`research/homelessness/flagship/send_package/build/` in the source repository.*
